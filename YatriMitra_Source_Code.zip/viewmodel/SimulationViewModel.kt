// SimulationViewModel placeholder
