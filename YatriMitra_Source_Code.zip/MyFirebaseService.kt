// Firebase notification service placeholder
