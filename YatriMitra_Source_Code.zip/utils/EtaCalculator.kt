// EtaCalculator placeholder
