// MainActivity placeholder for Yatri-Mitra
